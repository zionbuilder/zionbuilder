<?php
echo 'Directory browsing is not allowed!';
